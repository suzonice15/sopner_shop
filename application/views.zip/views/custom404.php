<section id="content" class="main">
	<section class="container">
		<div class="row">
			<div class="col-sm-12 text-center">
				<h1>404</h1>
				<p>Sorry web page is not available!</p>
				<p><a href="<?=base_url()?>" class="btn btn-default back-to-home">Go Back To Home</a></p>
			</div>
		</div>
	</section>
</section>