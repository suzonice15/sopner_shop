<div class="row" style="background: #f69451;">
	<div class="col-sm-12 col-md-6 columnyy" style="background: #f69451; text-align: center;">
		<h4 style="text-align: center; widows: 100%; padding-top: 30px; font-size: 35px; color: white; overflow: hidden; padding-bottom: 15px;">We Are Social</h4>
		<div class="social-icons">
			<a class="facebook" target="_blank" href="https://www.facebook.com/jncomputerbd" ><i class="fa fa-fw fa-facebook"></i> </a>
			<a class="facebook" target="_blank" href="#" ><i class="fa fa-fw fa-twitter"></i> </a>
			<a class="facebook" target="_blank" href="https://www.youtube.com/channel/UCsgyMztpLbjwTlF6eEbYiuA?view_as=subscriber" ><i class="fa fa-fw fa-youtube-play"></i> </a>
			<a class="facebook" target="_blank" href="https://www.linkedin.com/company/20441431" ><i class="fa fa-fw fa-linkedin"></i> </a>

		</div>
		<br /><br /></div>
	<div class="col-sm-12 col-md-6 columnyy" style="background: #f9f0eb;"><img class="mobilexxview" src="https://www.jncomputerbd.com/images/payment.jpg" /></div>
</div>
<div class="container">
	<div class="row" style="margin-top: 30px;">
		<div class="col-sm-12 col-md-3 column">
			<div class="column-title">Showroom</div>
			<p>Shop# 764, Level# 7, <br />Multiplan Center, 69-71, <br />New Elephant Road Dhaka 1205 <br />+8801837441061 <br />+8801837441062 <br />+8801837441063 <br />support@.jncomputerbd.com</p>
		</div>
		<div class="col-sm-12 col-md-3 column">
			<div class="column-title">MY ACCOUNT</div>
			<ul>
				<li class="column-links"><a href="#">Sign In</a></li>
				<li class="column-links"><a href="#">View Cart</a></li>
				<li class="column-links"><a href="#">Track Your Order</a></li>
				<li class="column-links"><a href="#">Help</a></li>
			</ul>
		</div>
		<div class="col-sm-12 col-md-3 column ">
			<div class="box box1">
				<div class="column-title">INFORMATION</div>
				<ul>
					<li class="column-links"><a href="https://www.jncomputerbd.com/warranty-policy">Warranty Policy</a></li>
					<li class="column-links"><a href="#">Replacement Policy</a></li>
					<li class="column-links"><a href="#">Why Shop with Us</a></li>
					<li class="column-links"><a href="#">Terms And Condition</a></li>
					<li class="column-links"><a href="#">Contact Us</a></li>
					<li class="column-links"><a href="#">About Us</a></li>
					<li class="column-links"><a href="#">Our Blog</a></li>
				</ul>
			</div>
		</div>
		<div class="col-sm-12 col-md-3 column ">
			<div class="box box1">
				<div class="column-title">MEMBER OF BANGLADESH COMPUTER SAMITY</div>
				<ul>
					<li class="column-links"><a href="#"><img src="https://www.jncomputerbd.com/images/memberlogo.jpg" /></a></li>
				</ul>
			</div>
		</div>
		<div class="col-sm-12 col-md-3 columnxx" style="height: 20px !important;">
			<div class="box box1">&nbsp;</div>
		</div>
	</div>
</div>
